export default () => {
    return {
        theme: {
            token: {
                colorPrimary: '#00d596',
            }
        }
    }
}