const config = {
    webhookUrl: 'https://webhook.site/338629d7-1c7a-4b45-a5fc-e9ca763b1501'
};

export default config