const schemaOption = [
    {
        label: 'First Name',
        value: 'first_name',
        primaryColor: 'hsl(102, 53%, 61%)',
        option: [
            { label: 'Gunaseelan', value: 'Gunaseelan' },
            { label: 'Munish', value: 'Munish' }
        ]
    },
    {
        label: 'Last Name',
        value: 'last_name',
        primaryColor: "#f50",
        option: [
            { label: 'Kumar', value: 'Kumar' },
            { label: 'Raj', value: 'Raj' }
        ]
    },
    {
        label: 'Gender',
        value: 'gender',
        primaryColor: "hwb(205 6% 9%)",
        option: [
            { label: 'Male', value: 'male' },
            { label: 'Female', value: 'female' },
            { label: 'Others', value: 'others' }
        ]
    },
    {
        label: 'Age',
        value: 'age',
        primaryColor: "#f50",
        option: [
            { label: '21', value: '21' },
            { label: '22', value: '22' },
            { label: '23', value: '24' }
        ]
    },
    {
        label: 'Account Name',
        value: 'account_name',
        primaryColor: "#f50",
        option: [
            { label: 'Gunaseelan Kumar', value: 'gunaseelan kumar' },
            { label: 'Munish Anbu', value: 'munish anbu' },
        ]
    },
    {
        label: 'City',
        value: 'city',
        primaryColor: "#f50",
        option: [
            { label: 'Chennai', value: 'Chennai' },
            { label: 'Mumbai', value: 'Mumbai' },
        ]
    },
    {
        label: 'State',
        value: 'state',
        primaryColor: "#f50",
        option: [
            { label: 'Tamil Nadu', value: 'tamilnadu' },
            { label: 'Maharastra', value: 'maharastra' },
        ]
    },
]

export default schemaOption;