import * as LocalDataBase from './localDatabase';
import schemaOptions from './schemaOptions';

const mockedData = {
    LocalDataBase,
    schemaOptions
};

export default mockedData;