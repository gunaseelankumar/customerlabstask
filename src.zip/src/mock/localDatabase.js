export function getLocalStorage(key) {
    const parsedData = JSON.parse(window.localStorage.getItem(key?.trim()?.toString()));
    return parsedData;
};

export function setLocalStorage(key, value, type = 'add') {
    const existingValues = getLocalStorage(key) || [];

    if (type === 'edit') {
        const updatedValue = existingValues?.map((item) => {
            if (item?.uuid === value?.uuid) {
                return value
            } else {
                return item
            }
        })

        window.localStorage.setItem(key, JSON.stringify(updatedValue));
    } else if (type === 'delete') {
        const updatedValue = existingValues?.filter((item) => item?.uuid !== value?.uuid);
        window.localStorage.setItem(key, JSON.stringify(updatedValue));
        return updatedValue
    }
    else if (type === 'add') {
        const localArray = [...existingValues, { ...value, uuid: getRandomChar() }]
        window.localStorage.setItem(key, JSON.stringify(localArray));
    }

    return getLocalStorage(key);
};

function getRandomChar() {
    const randLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26));
    return randLetter + Date.now();;
}
