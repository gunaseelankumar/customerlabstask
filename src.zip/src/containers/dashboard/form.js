import React from "react";
import { Badge, Button, Form, Input, Select } from 'antd';
import FormItem from "antd/es/form/FormItem";
import { MinusOutlined, PlusOutlined } from "@ant-design/icons";
import mock from '../../mock/index'

export function FormComp({ form, handleAddSchema, handleDelete, handleSelect, SchemaContext, selectedSchema }) {

    function handleFieldChange(fieldName, fieldValue) {
        form?.setFieldValue(fieldName, fieldValue?.value)
    }

    return (
        <>
            <Form form={form}>
                <span className="console-form-label">Enter The Name  Of The Segment</span>
                <FormItem name="segment_name" rules={[{ required: true, message: 'Please Input Segment Name!' }]}>
                    <Input placeholder="Name of the segment" />
                </FormItem>
                <span className="console-form-info-text">To Save Your Segment, You Need To Add The Schemas To Build The Query</span><br />
                <div style={{ marginTop: '1rem' }}>
                    <div className={`console-drawer-dynamicFields-${SchemaContext?.selectedSchema?.length > 0 ? 'blueBorder' : 'noBorder'}`}>
                        {
                            SchemaContext?.selectedSchema?.map((schema, index_key) => {
                                const commonBody = mock?.schemaOptions?.find((option) => option?.value === schema);
                                return (
                                    <div key={index_key?.toString()} style={{ display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '1rem' }}>
                                        <Badge color={commonBody?.primaryColor} />
                                        <FormItem style={{ marginBottom: 0, width: '100%' }} name={schema}>
                                            <Select name={schema} options={commonBody?.option} onChange={handleFieldChange} placeholder={`${commonBody?.label}`} />
                                        </FormItem>
                                        <Button onClick={() => handleDelete(schema)} icon={<MinusOutlined />} />
                                    </div>
                                )
                            })
                        }
                    </div>
                    <FormItem style={{ marginTop: '1rem' }}>
                        <Select
                            showArrow={true}
                            value={selectedSchema}
                            placeholder="Add schema to segment"
                            options={mock?.schemaOptions?.filter((schema) => !SchemaContext?.selectedSchema?.includes(schema?.value))} onChange={handleSelect} />
                    </FormItem>
                </div>
                <div>
                    <Button icon={<PlusOutlined />} disabled={!selectedSchema} onClick={handleAddSchema} style={{ paddingLeft: 0 }} type="link" >Add New Schema</Button>
                </div>
            </Form>
        </>
    )
}