import React, { useRef } from "react";
import { Badge, Button, Drawer, Form, Input, message, Select } from 'antd';
import { FormComp } from "./form";
import config from "../../config";
const drawerProperties = { isOpen: false, type: 'create', selectedValue: {} };

export function Dashboard(props) {
    const [form] = Form.useForm();
    const [DrawerContext, setDrawerContext] = React.useState(drawerProperties);

    function handleOpenDrawer(type, selectedValue) {
        setDrawerContext((prevState) => ({ ...prevState, isOpen: true, type: type, selectedValue: selectedValue }))
    };

    function handleClose() {
        setDrawerContext((prevState) => ({ ...prevState, isOpen: false }))
    }

    const drawerProps = {
        open: DrawerContext?.isOpen,
        type: DrawerContext?.type,
        selectedValue: DrawerContext?.selectedValue,
        onClose: handleClose,
        title: 'Saving Segment',
        footer: <DrawerFooter form={form} handleClose={handleClose} />
    }

    return (
        <div style={{ margin: 'auto', width: '100%', display: 'flex', justifyContent: 'center', height: '100vh', alignItems: 'center' }}>
            <div>
                <Button type='primary' onClick={() => handleOpenDrawer('create')}>Click To Add Scheme To Segment</Button>
            </div>
            <DrawerComp {...drawerProps} form={form} />
        </div>
    )
};

function DrawerFooter({ form, handleClose }) {
    const [messageApi, contextHolder] = message.useMessage();
    const [isSaving, setIsSaving] = React.useState(false)

    function handleSave() {
        form?.validateFields().then((values) => {
            let formData = {};
            formData.segment_name = values?.segment_name;
            delete values?.segment_name;
            formData.schema = Object.keys(values).map((keys) => {
                return {
                    [keys]: values[keys]
                }
            });
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            };
            setIsSaving(true);
            fetch(config?.webhookUrl?.toString(), requestOptions)
                .then(response => {
                    if (response) {
                        messageApi.open({
                            type: 'success',
                            content: 'Data Saved to Webhook',
                        });
                        console.info(`data was saved to following webhook url ${config?.webhookUrl}`)
                    };
                    setTimeout(() => handleClose(), 500)
                }).catch((err) => {
                    messageApi.open({
                        type: 'error',
                        content: 'Failed to add',
                    });
                    console.log('something went wrong with form')
                }).finally(() => {
                    setIsSaving(false);
                })
        })
    };

    return <div style={{ display: 'flex', gap: '5px' }}>
        {contextHolder}
        {
            [<Button key={1} type='primary' onClick={handleSave}>{isSaving ? 'Saving...' : 'Save the segment'}</Button>, <Button onClick={handleClose} key={2}>Cancel</Button>]
        }
    </div>
}

function DrawerComp(props) {
    const { form } = props;
    const [selectedSchema, setSelectedSchema] = React.useState()
    const [SchemaContext, setSchemaContext] = React.useState({ selectedSchema: [] })

    function handleSelect(value) {
        setSelectedSchema(value)
    };
    function handleDelete(key) {
        const filtered = SchemaContext?.selectedSchema?.filter((schema) => schema !== key);
        setSchemaContext((prevState) => ({ ...prevState, selectedSchema: filtered }))
    }
    function handleAddSchema() {
        setSchemaContext((prevState) => ({ ...prevState, selectedSchema: [...prevState?.selectedSchema, selectedSchema] }));
        setSelectedSchema(null)
    };

    let formProperties = {
        handleAddSchema,
        handleDelete,
        handleSelect,
        selectedSchema,
        SchemaContext
    }

    return <Drawer {...props} width={420}>
        <FormComp {...formProperties} form={form} />
    </Drawer>
}

