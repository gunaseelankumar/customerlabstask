import React, { Fragment } from 'react';
import './App.css';
import { ConfigProvider } from 'antd';
import { Dashboard } from './containers/dashboard';
import configAppProvider from './config/configappproviders';

function App() {
  return (
    <Fragment>
      <ConfigProvider theme={{ ...configAppProvider()?.theme }}>
        <Dashboard />
      </ConfigProvider>
    </Fragment>
  );
};
export default App;
