import { Layout } from "antd";
const { Sider } = Layout;

function Sidebar(props) {
    return (
        <Sider {...props} />
    )
};

export default Sidebar;