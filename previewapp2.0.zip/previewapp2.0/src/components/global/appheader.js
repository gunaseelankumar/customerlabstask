import { Avatar } from "antd";
import { Header } from "antd/es/layout/layout";
import { MenuOutlined } from '@ant-design/icons';
import './style.css';

export function AppHeader({ onMenuClick, ...props }) {
    return (
        <Header {...props}>
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px' }}>
                    <span title='open menu' className="console-menu-wrapper" onClick={onMenuClick}><MenuOutlined /></span>
                    <img width={'60px'} src='https://static.vecteezy.com/system/resources/previews/008/214/517/original/abstract-geometric-logo-or-infinity-line-logo-for-your-company-free-vector.jpg' />
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: '6px' }}>
                    <Avatar size='large' style={{ background: 'orange' }}>Gk</Avatar>
                    <span style={{ fontWeight: 500 }}>Gunaseelan</span>
                </div>
            </div>
        </Header>
    )
};
