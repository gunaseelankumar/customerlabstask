# FOR RUN THE PROJECT :

   note (before start the project, please to npm install form root project)
   say -> npm start

# FOR TEST THE PROJECT :

   say -> npm run text